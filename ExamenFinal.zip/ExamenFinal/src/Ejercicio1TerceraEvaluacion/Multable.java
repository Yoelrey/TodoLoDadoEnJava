package Ejercicio1TerceraEvaluacion;

public interface Multable {
int MULTA_MAXIMA=100;
String Multa(int cantidad);
String disminuirMulta(int cantidad);
String aumentarMulta(int cantidad);

}
